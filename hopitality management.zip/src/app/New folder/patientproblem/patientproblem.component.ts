import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientproblem',
  templateUrl: './patientproblem.component.html',
  styleUrls: ['./patientproblem.component.css']
})
export class PatientproblemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
