import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-doctor',
  templateUrl: './assign-doctor.component.html',
  styleUrls: ['./assign-doctor.component.css']
})
export class AssignDoctorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
