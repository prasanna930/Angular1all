import { Component, OnInit, Input, EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-communication',
  template:`
  <h2 style="color:blue;"> Data transfer between paent to child</h2>
  <h2>{{"hello" + na}}</h2>
  <button (click)="fireEvent()">send</button>

  `,
  styleUrls: ['./communication.component.scss']
})
export class CommunicationComponent implements OnInit {

 //@Input() public parentdata;

 @Input('parentdata') public na;

 @Output() public childEvent = new EventEmitter();


 constructor() { }

 ngOnInit() {
 }


 fireEvent()
  {
    this.childEvent.emit( 'hello parent');
  }
}
