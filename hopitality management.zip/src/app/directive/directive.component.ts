import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive',
  templateUrl: './directive.component.html',

  styles : [`
    .text-success{
      color:green;
    }

    .text-danger{
      color:red;

      .text-special{
        font-style:italc;
      }
    }
  `]
})
export class DirectiveComponent implements OnInit {
  //ngif
  displayTag: boolean = true;


//style
public haserror=false;
  public title={
    color:"blue",
    fontStyle:"italic"

  }

  //ngfor
  public fastfoods=["sandwich", "pizza", "burger", "hot dog"]

//ngswitch
   public color="red";
   public color1="green"
   public color2="blue"


//ngclass
public successclass="text-success";
public haserro1=false;


  constructor() { }




  ngOnInit() {
  }

}
