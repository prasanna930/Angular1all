import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-doctorspage',
  templateUrl: './doctorspage.component.html',

  styleUrls: ['./doctorspage.component.css']
})
export class DoctorspageComponent implements OnInit {
  title1="";
  constructor() { }

  ngOnInit() {
  }

}
