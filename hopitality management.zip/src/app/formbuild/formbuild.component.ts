import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';


interface City {
  name: string;
  code: string;
}

@Component({
  selector: 'app-formbuild',
  templateUrl: './formbuild.component.html',
  styleUrls: ['./formbuild.component.css']
})
export class FormbuildComponent implements OnInit {

  Registartionform: FormGroup;

  cities2: City[];

  constructor(private fb: FormBuilder) {


    this.cities2 = [
      {name: 'Anv', code: 'NY'},
      {name: 'kkd', code: 'RM'},
      {name: 'London', code: 'LDN'},
      {name: 'vskp', code: 'IST'},
      {name: 'bnglr', code: 'PRS'}
  ];

}

  ngOnInit() {
    this.Registartionform= this.fb.group({
      name1:['',Validators.required],
      CreateUserid: [''],
      ReenterUserid: [''],
      gender: [''],

      address: this.fb.group({
        city:['vskp'],
        state: [''],
        pincode: ['']


      })
    });
  }


onSubmit() : void {
  console.log(this.Registartionform.value);
  console.log(this.Registartionform.touched);
  console.log(this.Registartionform.controls.CreateUserid.touched);

}

}
