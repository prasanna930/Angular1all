import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HhomepageComponent } from './hhomepage.component';

describe('HhomepageComponent', () => {
  let component: HhomepageComponent;
  let fixture: ComponentFixture<HhomepageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HhomepageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HhomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
