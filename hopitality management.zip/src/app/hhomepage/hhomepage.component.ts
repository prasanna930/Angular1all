import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hhomepage',
  templateUrl: './hhomepage.component.html',
  styleUrls: ['./hhomepage.component.css']
})
export class HhomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
