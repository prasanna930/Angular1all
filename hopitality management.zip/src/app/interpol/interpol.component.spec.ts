import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterpolComponent } from './interpol.component';

describe('InterpolComponent', () => {
  let component: InterpolComponent;
  let fixture: ComponentFixture<InterpolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterpolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterpolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
