import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interpol',
  templateUrl: './interpol.component.html',

  styleUrls: ['./interpol.component.scss']


})
export class InterpolComponent implements OnInit {

  welcomeMessage :string= 'Welcome to Angular Data Binding Example!!';

  imagePath: string = 'assets/images/miracle.png';
  currentValue: boolean = false;

  title = 'Learning string interpolation';
  constructor() { }

  ngOnInit() {
  }
    changeMyTitle() {

      this.title = 'Learning Event Binding';
  }

}
