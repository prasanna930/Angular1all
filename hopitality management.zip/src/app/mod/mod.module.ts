import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Mod1Component } from './mod1/mod1.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [Mod1Component],
  exports : [Mod1Component]
})
export class ModModule { }
