import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Multiple1Component } from './multiple1.component';

describe('Multiple1Component', () => {
  let component: Multiple1Component;
  let fixture: ComponentFixture<Multiple1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Multiple1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Multiple1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
