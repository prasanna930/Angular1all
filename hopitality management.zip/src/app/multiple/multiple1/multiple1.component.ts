import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multiple1',
  templateUrl: './multiple1.component.html',
  styleUrls: ['./multiple1.component.scss']
})
export class Multiple1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
