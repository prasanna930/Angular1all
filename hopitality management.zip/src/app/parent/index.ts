// start:ng42.barrel
export * from './parent.component';
// end:ng42.barrel

