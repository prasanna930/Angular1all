import { Component } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.scss']
})
export class PipesComponent  {
birthday= new Date(1997, 3, 11)
name : string = " lakshmi krishna sri";
public date= new Date()
public person= {
  "name":"lea",
  "age":"2"

}



}
