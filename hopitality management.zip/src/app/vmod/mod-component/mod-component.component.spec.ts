import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModComponentComponent } from './mod-component.component';

describe('ModComponentComponent', () => {
  let component: ModComponentComponent;
  let fixture: ComponentFixture<ModComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
