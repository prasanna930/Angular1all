import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod-component',
  templateUrl: './mod-component.component.html',
  styleUrls: ['./mod-component.component.css']
})
export class ModComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
