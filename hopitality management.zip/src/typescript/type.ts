



// // -------------push-----------------
// var numbers = new Array(1, 2, 3);
// var length = numbers.push(4);
// console.log(" pushed new numbers is : " + numbers );
// length = numbers.push(20);
// console.log("pushed new numbers is : " + numbers );
// //------------pop-------------------
// var element = numbers.pop();
// console.log("poped element is : " + element );
// //--------------reverse--------------
// var arr = [0, 1, 2, 3].reverse();
// console.log("Reversed array is : " + arr );
// //------------------concat-------------
// var alpha = ["a", "b", "c"];
// var num = [1, 2, 3];

// var alphaNumeric = alpha.concat(num);
// console.log("alphaNumeric : " + alphaNumeric );
// //------------------------------filter----------------------
// function filt(elem, index, array) {
//     return (elem >= 10);
//  }

//  var passed = [1, 2, 99, 50].filter(filt);
//  console.log("Result is : " + passed );
// //---------------------------slice---------------------------
// var arr = ["orange", "mango", "banana", "sugar", "tea"];
// console.log("arr.slice( 1, 2) : " + arr.slice( 1, 2) );
// console.log("arr.slice( 1, 3) : " + arr.slice( 1, 3) );
// var sorted = arr.sort(); // ---------------sort method----
// console.log("Returned string is : " + sorted );


// // //--------------------map------------------------
// // var numbers = [1, 4, 9];
// // var roots = numbers.map(Math.sqrt);
// // console.log("roots is : " + roots );

